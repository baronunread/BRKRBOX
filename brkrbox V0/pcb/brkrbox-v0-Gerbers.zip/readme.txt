Project Name: Brkrbox V0
Project Version: #cc28609a
Project Url: https://www.flux.ai/baronunread/brkrbox-v0

Project Description:
Flatbox styled hand solderable PCB featuring a side passthrough, oled screen, focus mode and DP/LS/RS switch


